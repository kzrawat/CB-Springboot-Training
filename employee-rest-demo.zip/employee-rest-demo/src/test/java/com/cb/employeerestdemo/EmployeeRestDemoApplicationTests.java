package com.cb.employeerestdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
