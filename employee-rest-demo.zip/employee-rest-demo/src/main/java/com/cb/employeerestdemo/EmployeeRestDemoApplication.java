package com.cb.employeerestdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeRestDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeRestDemoApplication.class, args);
	}

}
